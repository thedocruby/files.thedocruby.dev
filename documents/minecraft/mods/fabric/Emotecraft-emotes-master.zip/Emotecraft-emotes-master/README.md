# Emotecraft
Emotecraft is a Minecraft mod to add emotes to the game like in Bedrock Edition. For more infomation on the mod itself go here:
https://www.curseforge.com/minecraft/mc-mods/emotecraft

## This is the pulic respository to find, download, and add community made emotes

### Downloading Other People's Custom Emotes:
To download an emote click the button that says "Code" and then download zip. Then unzip it and head to the emotes folder inside. After, copy the emotes you want to  %appdata%\\.minecraft\emotes. You should see it apear ingame in the "All Emotes" menu.

### Requesting Someone To Add Your Custom Emotes
There are two ways, you can either ask in #customemotes in the discord server https://discord.com/invite/6NfdRuE or bye
going to the "Issues" tab and clicking "New Issue." Then Click "Labels" and select "emote request". Then create a title and description, and make sure to add either a pastebin link or the file to to the issue. Then click submit and someone will review it and add it or give you feedback on how to improve.
